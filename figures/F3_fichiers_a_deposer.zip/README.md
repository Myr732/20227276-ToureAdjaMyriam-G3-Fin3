# F3 — Prévision de l’inflation américaine à 12 mois

**Auteur :** Toure Adja Myriam — **Code Apogée :** 20227276 — **Groupe :** G3-Fin3

Ce projet compare la régression Ridge à une référence naïve sur les données mensuelles américaines de FRED. L’objectif est d’évaluer la contribution du chômage et du taux des fonds fédéraux. Les variables sont retardées, le découpage est chronologique et le réglage s’effectue par validation temporelle.

## Problématique et résultats
Le chômage et le taux d’intérêt améliorent-ils la prévision de l’inflation en glissement annuel à douze mois ? L’objectif de Ridge complet est de réduire le RMSE de la référence d’au moins 10 %.

| Modèle | RMSE validation | RMSE test | MAE test | R² test |
|---|---:|---:|---:|---:|
| Méthode naïve | 2,0328 | 2,1777 | 1,5336 | −0,2060 |
| Ridge réduit | 2,2740 | 1,9556 | 1,4431 | 0,0275 |
| Ridge complet | 2,4711 | 2,1182 | 1,4892 | −0,1410 |

Ridge complet réduit le RMSE de 2,73 %, en deçà de l’objectif. L’ajout du chômage et du taux d’intérêt n’améliore pas le résultat par rapport à Ridge réduit sur cette période. Les performances varient selon les régimes économiques ; les données révisées peuvent entraîner un biais d’anticipation.

## Données
- CPIAUCSL et UNRATE (U.S. Bureau of Labor Statistics), FEDFUNDS (Board of Governors of the Federal Reserve System), diffusés par FRED.
- https://fred.stlouisfed.org/series/CPIAUCSL
- https://fred.stlouisfed.org/series/UNRATE
- https://fred.stlouisfed.org/series/FEDFUNDS
- Attribution demandée (Public Domain: Citation Requested). [Conditions FRED](https://fred.stlouisfed.org/legal/terms/).
- Dates d’extraction : [docs/references.md](docs/references.md). Les trois CSV d’origine sont dans `data/raw/`.

## Installation et exécution
Python 3.13.18 utilisé dans Colab.

```bash
pip install -r requirements.txt
```

Cloner le dépôt, ouvrir `notebooks/projet_F3.ipynb` dans Jupyter ou Google Colab et exécuter les cellules dans l’ordre après redémarrage. Les données brutes ne doivent pas être remplacées par une extraction plus récente si l’objectif est de reproduire exactement les chiffres. La durée d’exécution dépend de l’environnement ; généralement quelques minutes hors installation. Les graphiques sont enregistrés dans `figures/`.

## Structure du dépôt
- `data/raw/` : données brutes
- `docs/` : fiche F3 et références
- `notebooks/` : notebook exécuté
- `figures/` : graphiques
- `rapport/` : rapport PDF
- `presentation/` : six diapositives (PDF et source)

## Références et IA
Support `Tp_ML.ipynb`, [pandas](https://pandas.pydata.org/docs/), [scikit-learn](https://scikit-learn.org/stable/), [matplotlib](https://matplotlib.org/stable/).
Voir [DECLARATION_IA.md](DECLARATION_IA.md).
