# Déclaration d’utilisation de l’intelligence artificielle

Projet F3 — Prévision de l’inflation

| Outil / date | Usage précis | Parties concernées | Vérification effectuée ou à effectuer |
|---|---|---|---|
| ChatGPT (OpenAI), novembre 2026 | Explication des consignes, assistance à la création du dépôt et à la documentation des sources | GitHub, références | Dossiers et fichiers contrôlés dans GitHub |
| ChatGPT (OpenAI), novembre 2026 | Suggestions de code Python, correction d’erreurs, explication du modèle et du protocole | Sections 2 à 7 du notebook | Cellules exécutées dans Colab ; résultats et graphiques obtenus sur les CSV officiels |
| ChatGPT (OpenAI), novembre 2026 | Aide à la rédaction des commentaires, analyse critique et conclusion | Sections 2 à 10 | Chiffres confrontés aux sorties enregistrées du notebook |
| ChatGPT (OpenAI), 25 novembre 2026 | Réorganisation du notebook, retrait des exercices fictifs, ajout de compléments méthodologiques et de fichiers de remise | Notebook final, README, dépendances | Notebook réorganisé à relancer intégralement et compléments à vérifier avant remise |

Les choix méthodologiques, résultats et explications doivent être compris et validés par l’étudiante avant la remise. Les valeurs numériques rapportées proviennent des exécutions enregistrées, non de résultats inventés. Compléter cette déclaration si d’autres outils ou ressources sont utilisés.
